create definer = unimisuser@localhost view v_attendance_summary as
select `e`.`student_id`                                                                     AS `student_id`,
       `u`.`registration_no`                                                                AS `registration_no`,
       `usr`.`full_name`                                                                    AS `full_name`,
       `e`.`course_id`                                                                      AS `course_id`,
       `c`.`course_code`                                                                    AS `course_code`,
       `c`.`course_name`                                                                    AS `course_name`,
       count(`ar`.`attendance_record_id`)                                                   AS `total_sessions`,
       sum((case when (`ar`.`attendance_status` in ('PRESENT', 'LATE')) then 1 else 0 end)) AS `attended_sessions`,
       sum((case when (`ar`.`attendance_status` = 'MEDICAL') then 1 else 0 end))            AS `medical_sessions`,
       sum((case when (`ar`.`attendance_status` = 'ABSENT') then 1 else 0 end))             AS `absent_sessions`,
       ((sum((case when (`ar`.`attendance_status` in ('PRESENT', 'LATE')) then 1 else 0 end)) * 100.0) /
        nullif(count(`ar`.`attendance_record_id`), 0))                                      AS `raw_attendance_percent`,
       (((sum((case when (`ar`.`attendance_status` in ('PRESENT', 'LATE')) then 1 else 0 end)) + sum((case
                                                                                                          when (
                                                                                                              (`ar`.`attendance_status` = 'MEDICAL') and
                                                                                                              exists(select 1
                                                                                                                     from `unimis`.`medicals` `m`
                                                                                                                     where ((`m`.`attendance_record_id` = `ar`.`attendance_record_id`) and
                                                                                                                            (`m`.`approval_status` = 'Approved'))))
                                                                                                              then 1
                                                                                                          else 0 end))) *
         100.0) /
        nullif(count(`ar`.`attendance_record_id`), 0))                                      AS `adjusted_attendance_percent`
from (((((`unimis`.`enrollments` `e` join `unimis`.`undergraduates` `u`
          on ((`e`.`student_id` = `u`.`user_id`))) join `unimis`.`users` `usr`
         on ((`u`.`user_id` = `usr`.`user_id`))) join `unimis`.`courses` `c`
        on ((`e`.`course_id` = `c`.`course_id`))) left join `unimis`.`attendance_sessions` `ats`
       on ((`ats`.`course_id` = `c`.`course_id`))) left join `unimis`.`attendance_records` `ar`
      on (((`ar`.`attendance_session_id` = `ats`.`attendance_session_id`) and (`ar`.`student_id` = `e`.`student_id`))))
group by `e`.`student_id`, `u`.`registration_no`, `usr`.`full_name`, `e`.`course_id`, `c`.`course_code`,
         `c`.`course_name`;

