create definer = unimisuser@localhost view v_ca_summary as
select `e`.`student_id`                             AS `student_id`,
       `ug`.`registration_no`                       AS `registration_no`,
       `usr`.`full_name`                            AS `full_name`,
       `e`.`course_id`                              AS `course_id`,
       `c`.`course_code`                            AS `course_code`,
       `c`.`course_name`                            AS `course_name`,
       `c`.`ca_weight`                              AS `ca_weight`,
       round(coalesce(sum((case
                               when (`a`.`assessment_category` = 'CA') then ((`m`.`mark` * `a`.`weight_percent`) / 100)
                               else 0 end)), 0), 2) AS `ca_mark`,
       (case
            when (coalesce(sum((case
                                    when (`a`.`assessment_category` = 'CA')
                                        then ((`m`.`mark` * `a`.`weight_percent`) / 100)
                                    else 0 end)), 0) >= 40) then 'Eligible'
            else 'Not Eligible' end)                AS `ca_eligibility`
from (((((`unimis`.`enrollments` `e` join `unimis`.`undergraduates` `ug`
          on ((`e`.`student_id` = `ug`.`user_id`))) join `unimis`.`users` `usr`
         on ((`ug`.`user_id` = `usr`.`user_id`))) join `unimis`.`courses` `c`
        on ((`e`.`course_id` = `c`.`course_id`))) left join `unimis`.`assessments` `a`
       on (((`a`.`course_id` = `c`.`course_id`) and (`a`.`assessment_category` = 'CA')))) left join `unimis`.`marks` `m`
      on (((`m`.`assessment_id` = `a`.`assessment_id`) and (`m`.`student_id` = `e`.`student_id`))))
group by `e`.`student_id`, `ug`.`registration_no`, `usr`.`full_name`, `e`.`course_id`, `c`.`course_code`,
         `c`.`course_name`, `c`.`ca_weight`;

