create definer = unimisuser@localhost view v_eligibility as
select `unimis`.`ca`.`student_id`                                                                            AS `student_id`,
       `unimis`.`ca`.`registration_no`                                                                       AS `registration_no`,
       `unimis`.`ca`.`full_name`                                                                             AS `full_name`,
       `unimis`.`ca`.`course_id`                                                                             AS `course_id`,
       `unimis`.`ca`.`course_code`                                                                           AS `course_code`,
       `unimis`.`ca`.`course_name`                                                                           AS `course_name`,
       round(coalesce(`unimis`.`att`.`adjusted_attendance_percent`, 0),
             2)                                                                                              AS `attendance_percent`,
       round(`unimis`.`ca`.`ca_mark`, 2)                                                                     AS `ca_mark`,
       (case
            when ((coalesce(`unimis`.`att`.`adjusted_attendance_percent`, 0) >= 80) and (`unimis`.`ca`.`ca_mark` >= 40))
                then 'Eligible'
            else 'Not Eligible' end)                                                                         AS `final_exam_eligibility`,
       (case
            when (coalesce(`unimis`.`att`.`adjusted_attendance_percent`, 0) >= 80) then 'Pass Attendance Requirement'
            else 'Fail Attendance Requirement' end)                                                          AS `attendance_requirement`,
       (case
            when (`unimis`.`ca`.`ca_mark` >= 40) then 'Pass CA Requirement'
            else 'Fail CA Requirement' end)                                                                  AS `ca_requirement`
from (`unimis`.`v_ca_summary` `ca` left join `unimis`.`v_attendance_summary` `att`
      on (((`unimis`.`att`.`student_id` = `unimis`.`ca`.`student_id`) and
           (`unimis`.`att`.`course_id` = `unimis`.`ca`.`course_id`))));

