create definer = unimisuser@localhost view v_users as
select `u`.`user_id`                AS `user_id`,
       `u`.`username`               AS `username`,
       `u`.`password_hash`          AS `password_hash`,
       `u`.`role`                   AS `role`,
       `u`.`full_name`              AS `full_name`,
       `u`.`nic`                    AS `nic`,
       `u`.`date_of_birth`          AS `date_of_birth`,
       `u`.`gender`                 AS `gender`,
       `u`.`email`                  AS `email`,
       `u`.`contact_no`             AS `contact_no`,
       `u`.`address`                AS `address`,
       `u`.`profile_picture`        AS `profile_picture`,
       `u`.`department_id`          AS `department_id`,
       `u`.`user_status`            AS `user_status`,
       `u`.`created_at`             AS `created_at`,
       `u`.`updated_at`             AS `updated_at`,
       `d`.`department_code`        AS `department_code`,
       `d`.`department_name`        AS `department_name`,
       `a`.`admin_code`             AS `admin_code`,
       `l`.`lecturer_code`          AS `lecturer_code`,
       `t`.`technical_officer_code` AS `technical_officer_code`,
       `s`.`registration_no`        AS `registration_no`,
       `s`.`batch_year`             AS `batch_year`,
       `s`.`student_type`           AS `student_type`
from (((((`unimis`.`users` `u` left join `unimis`.`departments` `d`
          on ((`u`.`department_id` = `d`.`department_id`))) left join `unimis`.`admins` `a`
         on ((`u`.`user_id` = `a`.`user_id`))) left join `unimis`.`lecturers` `l`
        on ((`u`.`user_id` = `l`.`user_id`))) left join `unimis`.`technical_officers` `t`
       on ((`u`.`user_id` = `t`.`user_id`))) left join `unimis`.`undergraduates` `s`
      on ((`u`.`user_id` = `s`.`user_id`)));

