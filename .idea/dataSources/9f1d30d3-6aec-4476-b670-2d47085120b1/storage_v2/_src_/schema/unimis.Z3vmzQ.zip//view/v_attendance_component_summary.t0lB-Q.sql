create definer = unimisuser@localhost view v_attendance_component_summary as
select `ar`.`student_id`                                                                    AS `student_id`,
       `ug`.`registration_no`                                                               AS `registration_no`,
       `usr`.`full_name`                                                                    AS `full_name`,
       `ats`.`course_id`                                                                    AS `course_id`,
       `c`.`course_code`                                                                    AS `course_code`,
       `c`.`course_name`                                                                    AS `course_name`,
       `ats`.`component`                                                                    AS `component`,
       count(0)                                                                             AS `total_sessions`,
       sum((case when (`ar`.`attendance_status` in ('PRESENT', 'LATE')) then 1 else 0 end)) AS `attended_sessions`,
       sum((case when (`ar`.`attendance_status` = 'MEDICAL') then 1 else 0 end))            AS `medical_sessions`,
       sum((case when (`ar`.`attendance_status` = 'ABSENT') then 1 else 0 end))             AS `absent_sessions`,
       round(((sum((case when (`ar`.`attendance_status` in ('PRESENT', 'LATE')) then 1 else 0 end)) * 100.0) /
              nullif(count(0), 0)), 2)                                                      AS `raw_attendance_percent`,
       round((((sum((case when (`ar`.`attendance_status` in ('PRESENT', 'LATE')) then 1 else 0 end)) + sum((case
                                                                                                                when (
                                                                                                                    (`ar`.`attendance_status` = 'MEDICAL') and
                                                                                                                    exists(select 1
                                                                                                                           from `unimis`.`medicals` `m`
                                                                                                                           where ((`m`.`attendance_record_id` = `ar`.`attendance_record_id`) and
                                                                                                                                  (`m`.`approval_status` = 'Approved'))))
                                                                                                                    then 1
                                                                                                                else 0 end))) *
               100.0) / nullif(count(0), 0)),
             2)                                                                             AS `adjusted_attendance_percent`
from ((((`unimis`.`attendance_records` `ar` join `unimis`.`attendance_sessions` `ats`
         on ((`ar`.`attendance_session_id` = `ats`.`attendance_session_id`))) join `unimis`.`courses` `c`
        on ((`ats`.`course_id` = `c`.`course_id`))) join `unimis`.`undergraduates` `ug`
       on ((`ar`.`student_id` = `ug`.`user_id`))) join `unimis`.`users` `usr` on ((`ug`.`user_id` = `usr`.`user_id`)))
group by `ar`.`student_id`, `ug`.`registration_no`, `usr`.`full_name`, `ats`.`course_id`, `c`.`course_code`,
         `c`.`course_name`, `ats`.`component`;

