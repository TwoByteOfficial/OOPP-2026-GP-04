create definer = unimisuser@localhost view v_cgpa as
select `unimis`.`s`.`student_id`                                                         AS `student_id`,
       `unimis`.`s`.`registration_no`                                                    AS `registration_no`,
       `unimis`.`s`.`full_name`                                                          AS `full_name`,
       `u`.`previous_credits`                                                            AS `previous_credits`,
       round(`u`.`previous_grade_points`, 2)                                             AS `previous_grade_points`,
       round(`unimis`.`s`.`sgpa`, 2)                                                     AS `current_sgpa`,
       `unimis`.`s`.`semester_credits`                                                   AS `semester_credits`,
       round((`u`.`previous_grade_points` + `unimis`.`s`.`semester_grade_points`), 2)    AS `total_grade_points`,
       round(((`u`.`previous_grade_points` + `unimis`.`s`.`semester_grade_points`) /
              nullif((`u`.`previous_credits` + `unimis`.`s`.`semester_credits`), 0)), 2) AS `cgpa`
from (`unimis`.`v_sgpa` `s` join `unimis`.`undergraduates` `u` on ((`unimis`.`s`.`student_id` = `u`.`user_id`)));

