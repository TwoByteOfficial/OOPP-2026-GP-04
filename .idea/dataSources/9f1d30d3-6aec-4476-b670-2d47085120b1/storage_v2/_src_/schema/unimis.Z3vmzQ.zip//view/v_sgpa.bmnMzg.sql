create definer = unimisuser@localhost view v_sgpa as
select `unimis`.`v_final_results`.`student_id`                                                      AS `student_id`,
       `unimis`.`v_final_results`.`registration_no`                                                 AS `registration_no`,
       `unimis`.`v_final_results`.`full_name`                                                       AS `full_name`,
       round((sum((`unimis`.`v_final_results`.`grade_point` * `unimis`.`v_final_results`.`total_credits`)) /
              nullif(sum(`unimis`.`v_final_results`.`total_credits`), 0)), 2)                       AS `sgpa`,
       sum(`unimis`.`v_final_results`.`total_credits`)                                              AS `semester_credits`,
       sum((`unimis`.`v_final_results`.`grade_point` *
            `unimis`.`v_final_results`.`total_credits`))                                            AS `semester_grade_points`
from `unimis`.`v_final_results`
group by `unimis`.`v_final_results`.`student_id`, `unimis`.`v_final_results`.`registration_no`,
         `unimis`.`v_final_results`.`full_name`;

