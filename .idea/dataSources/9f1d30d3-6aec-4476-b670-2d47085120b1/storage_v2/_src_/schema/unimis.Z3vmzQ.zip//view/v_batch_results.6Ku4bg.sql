create definer = unimisuser@localhost view v_batch_results as
select `u`.`batch_year`                                                    AS `batch_year`,
       `unimis`.`r`.`course_code`                                          AS `course_code`,
       `unimis`.`r`.`course_name`                                          AS `course_name`,
       count(0)                                                            AS `student_count`,
       round(avg(`unimis`.`r`.`final_mark`), 2)                            AS `average_mark`,
       sum((case when (`unimis`.`r`.`grade_point` > 0) then 1 else 0 end)) AS `passed_count`,
       sum((case when (`unimis`.`r`.`grade_point` = 0) then 1 else 0 end)) AS `failed_count`
from (`unimis`.`v_final_results` `r` join `unimis`.`undergraduates` `u`
      on ((`unimis`.`r`.`student_id` = `u`.`user_id`)))
group by `u`.`batch_year`, `unimis`.`r`.`course_code`, `unimis`.`r`.`course_name`;

