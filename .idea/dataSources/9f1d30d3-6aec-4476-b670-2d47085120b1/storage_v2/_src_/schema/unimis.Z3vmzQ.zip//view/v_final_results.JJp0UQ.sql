create definer = unimisuser@localhost view v_final_results as
select `e`.`student_id`                                                                                        AS `student_id`,
       `ug`.`registration_no`                                                                                  AS `registration_no`,
       `usr`.`full_name`                                                                                       AS `full_name`,
       `e`.`course_id`                                                                                         AS `course_id`,
       `c`.`course_code`                                                                                       AS `course_code`,
       `c`.`course_name`                                                                                       AS `course_name`,
       `c`.`total_credits`                                                                                     AS `total_credits`,
       round(coalesce(`unimis`.`ca`.`ca_mark`, 0), 2)                                                          AS `ca_mark`,
       round(coalesce(`unimis`.`fe`.`final_exam_contribution`, 0), 2)                                          AS `final_exam_mark`,
       round((coalesce(`unimis`.`ca`.`ca_mark`, 0) + coalesce(`unimis`.`fe`.`final_exam_contribution`, 0)),
             2)                                                                                                AS `final_mark`,
       coalesce(`unimis`.`att`.`adjusted_attendance_percent`, 0)                                               AS `attendance_percent`,
       (case
            when ((coalesce(`unimis`.`att`.`adjusted_attendance_percent`, 0) >= 80) and
                  (coalesce(`unimis`.`ca`.`ca_mark`, 0) >= 40)) then 'Eligible'
            else 'Not Eligible' end)                                                                           AS `eligibility`,
       (select `gs`.`grade_code`
        from `unimis`.`grade_scales` `gs`
        where (`gs`.`minimum_mark` <=
               round((coalesce(`unimis`.`ca`.`ca_mark`, 0) + coalesce(`unimis`.`fe`.`final_exam_contribution`, 0)), 2))
        order by `gs`.`minimum_mark` desc
        limit 1)                                                                                               AS `grade`,
       (select `gs`.`grade_point`
        from `unimis`.`grade_scales` `gs`
        where (`gs`.`minimum_mark` <=
               round((coalesce(`unimis`.`ca`.`ca_mark`, 0) + coalesce(`unimis`.`fe`.`final_exam_contribution`, 0)), 2))
        order by `gs`.`minimum_mark` desc
        limit 1)                                                                                               AS `grade_point`
from ((((((`unimis`.`enrollments` `e` join `unimis`.`undergraduates` `ug`
           on ((`e`.`student_id` = `ug`.`user_id`))) join `unimis`.`users` `usr`
          on ((`ug`.`user_id` = `usr`.`user_id`))) join `unimis`.`courses` `c`
         on ((`e`.`course_id` = `c`.`course_id`))) left join `unimis`.`v_ca_summary` `ca`
        on (((`unimis`.`ca`.`student_id` = `e`.`student_id`) and
             (`unimis`.`ca`.`course_id` = `e`.`course_id`)))) left join `unimis`.`v_final_exam_marks` `fe`
       on (((`unimis`.`fe`.`student_id` = `e`.`student_id`) and
            (`unimis`.`fe`.`course_id` = `e`.`course_id`)))) left join `unimis`.`v_attendance_summary` `att`
      on (((`unimis`.`att`.`student_id` = `e`.`student_id`) and (`unimis`.`att`.`course_id` = `e`.`course_id`))));

